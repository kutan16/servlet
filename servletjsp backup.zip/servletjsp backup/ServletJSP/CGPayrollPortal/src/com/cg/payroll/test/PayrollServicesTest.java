package com.cg.payroll.test;

public class PayrollServicesTest {

//	private static PayrollServices services;
//
//	@BeforeClass
//	public static void setUpTestEnv() {
//		services=new PayrollServicesImpl();
//	}
//
//	@Before
//	public void setUpTestData() {
//		Associate associate1=new Associate(101,20000,"nilotpal","majumdar","java","intern","asd23232","kutan16@gmail.com",new Salary(12000,1800,1800),new BankDetails(12345, "sbi", "sbin00083"));
//		Associate associate2=new Associate(102,10000,"lock","kutan","java","intern","asd32323","lock@gmail.com",new Salary(12000,1800,1800),new BankDetails(12345, "sbi", "sbin00083"));
//		PayrollDBUtil.associates.put(associate1.getAssociateId(), associate1);
//		PayrollDBUtil.associates.put(associate2.getAssociateId(), associate2);
//		PayrollDBUtil.ASSOCIATE_ID_COUNTER=102;
//	}
//
//	@Test(expected=AssociateDetailsNotFoundException.class)
//	public void testGetAssociateDetailsForInvalidAssociateId() throws AssociateDetailsNotFoundException {
//		services.getAssociateDetails(1234);
//	}
//	@Test
//	public void testGetAssociateDetailsForValidAssociateId() throws AssociateDetailsNotFoundException {
//		Associate expectedAssociate=new Associate(101,20000,"nilotpal","majumdar","java","intern","asd23232","kutan16@gmail.com",new Salary(12000,1800,1800),new BankDetails(12345, "sbi", "sbin00083"));
//		Associate actualAssociate = services.getAssociateDetails(101);
//		Assert.assertEquals(expectedAssociate, actualAssociate);
//	}
//
//	@Test
//	public void testAcceptAssociateDetailsForValidData() {
//		int expectedID=103;
//		int actualId=services.acceptAssociateDetails("abc", "jkl", "abc@jkl", "try", "sdxd", "asgfgfd23", 10000, 4000, 300, 400, 2343543, "lol", "lol230sd");
//		Assert.assertEquals(expectedID, actualId);
//	}
//	@Test
//	public void testGetAllAssociateDetails() {
//		Associate associate1=new Associate(101,20000,"nilotpal","majumdar","java","intern","asd23232","kutan16@gmail.com",new Salary(12000,1800,1800),new BankDetails(12345, "sbi", "sbin00083"));
//		Associate associate2=new Associate(102,10000,"lock","kutan","java","intern","asd32323","lock@gmail.com",new Salary(12000,1800,1800),new BankDetails(12345, "sbi", "sbin00083"));
//		ArrayList<Associate>expectedAssociateList = new ArrayList<>();
//		expectedAssociateList.add(associate1);
//		expectedAssociateList.add(associate2);
//		ArrayList<Associate>actualAssociateList = (ArrayList<Associate>)services.getAllAssociateDetails();
//		Assert.assertEquals(expectedAssociateList, actualAssociateList);
//	}
//
//	@Test//(expected=AssociateDetailsNotFoundException.class)
//	public void testCalculateNetSalaryForInvalidAssociateId() throws AssociateDetailsNotFoundException {
//		int expectedNetSalary=(int) services.calculateNetSalary(101);
//		Associate associate=new Associate(102,10000,"lock","kutan","java","intern","asd32323","lock@gmail.com",new Salary(12000,1800,1800),new BankDetails(12345, "sbi", "sbin00083"));
//		int actualNetSalary=(int)services.calculateNetSalary(101);
//		Assert.assertEquals(expectedNetSalary, actualNetSalary);
//	
//	}
//	
//	@Test
//	public void testCalculateNetSalaryForValidAssociateId() throws AssociateDetailsNotFoundException {
//		int expectedNetSalary=334800;
//		int actualNetSalary= (int) services.calculateNetSalary(101);
//		Assert.assertEquals(expectedNetSalary, actualNetSalary);
//	}
//
//	@After
//	public void tearDownTestData() {
//		PayrollDBUtil.associates.clear();
//		PayrollDBUtil.ASSOCIATE_ID_COUNTER=100;
//	}
//
//	@AfterClass
//	public static void tearDownTestEnv() {
//		services=null;
//	}
}
